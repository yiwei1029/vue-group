<template>
    <section class="NewTemplate">

    </section>
</template>

<script>
export default {
    name: 'NewTemplate',
    data() {
        return {

        }
    },
    components: {},
    watch: {},
    mounted() { },
    methods: {}
}
</script>

<style scoped lang="less"></style>
